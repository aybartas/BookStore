
DROP TABLE if exists `bookstore`.`campaign`;
DROP TABLE if exists `bookstore`.`book`;
DROP TABLE if exists `bookstore`.`Subcategory`;
DROP TABLE if exists `bookstore`.`category`; 