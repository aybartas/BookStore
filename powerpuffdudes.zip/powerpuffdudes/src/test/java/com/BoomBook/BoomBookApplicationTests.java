package com.BoomBook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoomBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
