
insert into category(title) values ("Education");
insert into category(title) values ("Novel");
 
insert into subcategory(category_id, title) values (1, "High School");
 


insert into book(author_name,subcategory_id,publish_year,title,isbn,image_url,publisher_name,subjects,count,price) value ('H.P. Lovecraft',2, 1928, 'The Call of Cthulhu', 1291239123, 'https://images-na.ssl-images-amazon.com/images/I/51CubRcaCYL._SX321_BO1,204,203,200_.jpg','Atlas', 'Fascinating story !!', 2, 22);
